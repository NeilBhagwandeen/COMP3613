/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studytimetable;

/**
 *
 * @author Neil Bhagwandeen
 */
import java.util.*;
public class ExamDay extends Day implements TestDay
{
    protected String time;
    protected String location;
    protected int difficulty;
    
    
    public ExamDay (String courseCode, Date date, String time, String location, int difficulty){
        super(courseCode, date);
        this.time = time;
        this.location = location;
        this.difficulty = difficulty;
    }
    
    
    @Override
    public String get_courseCode (){
        return courseCode;
    }
    
    @Override
    public Date get_date(){
        return date;
    }
    
    @Override
    public String get_time (){
        return time;
    }
    
    @Override
    public String get_location (){
        return location;
    }
    
    @Override
    public int get_difficulty (){
        return difficulty;
    }
    
    
    @Override
    public void set_courseCode(String courseCode){
        this.courseCode = courseCode;
    }
    
    @Override
    public void set_date(Date date){
        this.date = date;
    }
    
    @Override
    public void set_time(String time){
        this.time = time;
    }
    
    @Override
    public void set_location(String location){
        this.location = location;
    }
    
    @Override
    public void set_difficulty(int difficulty){
        this.difficulty = difficulty;
    }
}