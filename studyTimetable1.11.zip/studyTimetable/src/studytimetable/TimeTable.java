/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studytimetable;

/**
 *
 * @author Neil Bhagwandeen
 */
import java.text.SimpleDateFormat;
import java.util.*;
public class TimeTable {
    private TreeMap <Date,Day> timeTable;
    
    public TimeTable(){
        timeTable = new TreeMap <>();
    }
    
    public boolean addDay(Day d){
        timeTable.put(d.get_date(),d);
        return true;
    }
    
    public boolean deleteDay(Date d){
        if(timeTable.isEmpty())
            return false;
        if(timeTable.get(d)==(null))
            return false;
        timeTable.remove(d);
        return true;
    }
    
    public boolean editDay(Day d){
        if(timeTable.isEmpty())
            return false;
        if (timeTable.isEmpty())
            return false;
        timeTable.get(d.get_date()).set_courseCode(d.get_courseCode());
        timeTable.get(d.get_date()).set_location(d.get_location());
        timeTable.get(d.get_date()).set_time(d.get_time());
        timeTable.get(d.get_date()).set_difficulty(d.get_difficulty());
        return true;
    }
    
    public String printDay(Date d){
        if(timeTable.isEmpty())
            return null;
        if(timeTable.get(d)==(null))
            return null;
        Day tday = timeTable.get(d);
        String str = "";
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/YYYY");
        str =  str + formatter.format(d)+ "\n";
        str = str + tday.get_courseCode() + "\n";
        if(tday instanceof TestDay){
            str = str + tday.get_time() + "\n";
            str = str + tday.get_location() + "\n";
            str = str + tday.get_difficulty() + "\n";
        }
        return str;  
    }
    
}
