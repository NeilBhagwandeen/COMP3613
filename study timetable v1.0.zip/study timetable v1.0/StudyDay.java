
/**
 * Write a description of class StudyDay here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Date;
import java.util.*;
public class StudyDay extends Day
{
    public StudyDay (String courseCode, Date date){
        super(courseCode, date);
    }
    
    
    public String get_courseCode (){
        return courseCode;
    }
    
    public Date get_date(){
        return date;
    }
    
    public String get_time (){
        return null;
    }
    
    public String get_location (){
        return null;
    }
    
    public int get_difficulty (){
        return 0;
    }
    
    
    public void set_courseCode(String courseCode){
        this.courseCode = courseCode;
    }
    
    public void set_date(Date date){
        this.date = date;
    }
    
    public void set_time(String time){
        
    }
    
    public void set_location(String location){
        
    }
    
    public void set_difficulty(int difficulty){
        
    }
}
