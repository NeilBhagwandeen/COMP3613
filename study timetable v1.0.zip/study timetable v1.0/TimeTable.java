
/**
 * Write a description of class TimeTable here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.text.SimpleDateFormat;
import java.util.*;
public class TimeTable
{
    private static int numDays;
    private ArrayList<Day> timeTable;
    
    
    public TimeTable(){
        timeTable = new ArrayList<Day>();
        numDays = 0;
    }
    
    
    public boolean addDay(Day d){
        timeTable.add(d);
        numDays ++;
        return true;
    }
    
    public boolean removeDay(Day d){
        if(timeTable.size()==0){
            return false;
        }
        if(timeTable.indexOf(d)==-1){
            return false;
        }
        timeTable.remove(timeTable.indexOf(d));
        return true;
    }
    
    public void printState (){
        System.out.println("");
        if(timeTable.size()==0){
            return;
        }
        for(Day i:timeTable){
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/YYYY");
            System.out.println("Day: " + formatter.format(i.get_date()));
            //System.out.println("Day: "+ i.get_date());
            System.out.println("Course Code: " + i.get_courseCode());
            if (i instanceof TestDay){
                System.out.println("Time: " + i.get_time());
                System.out.println("Location: " + i.get_location());
                System.out.println("Difficulty: " + i.get_difficulty());
            }
            System.out.println("");
            System.out.println("");
        }
    }
    
    
    public static void main(String args[]){
        
        TimeTable t1 = new TimeTable ();
        Date date1 = new Date(119,9,29);
        
        Day di = new ExamDay("c1",date1,"1:00pm","JFK",5);
        t1.addDay(di);
        date1 = new Date (119,9,20);
        Day dj = new StudyDay("c1",date1);
        t1.addDay(dj);
        
        //Collections.sort(t1);
        t1.printState();
        
    }
}
