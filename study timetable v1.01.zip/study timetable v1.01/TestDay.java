
/**
 * Write a description of interface TestDay here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface TestDay
{
    
}
