

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.util.*;
/**
 * The test class TimeTableTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class TimeTableTest
{
    private TimeTable timeTable;
    private Date d;
    /**
     * Default constructor for test class TimeTableTest
     */
    public TimeTableTest()
    {
        timeTable = new TimeTable();
        d = new Date (2019,10,19);
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    @Test
    public void test_addDay(){
       //assumes that printDay(d) is correct
       Day d1 = new ExamDay ("COMP1234",d,"jfk","1:00pm",2);
       timeTable.addDay(d1);
       String str = "19/11/3919"+"\n"+"COMP1234"+"\n"+"jfk"+"\n"+"1:00pm"+"\n"+"2"+"\n";
       assertEquals(timeTable.printDay(d),str);
       
    }
    
    @Test
    public void test_deleteDay(){
       Day d1 = new ExamDay ("COMP1234",d,"jfk","1:00pm",2);
       timeTable.addDay(d1);
       timeTable.deleteDay(d);
       assertEquals(timeTable.printDay(d),null);
       
    }
    
    @Test
    public void test_printDay(){
       //assumes that addDay(d) is correct
       Day d1 = new ExamDay ("COMP1234",d,"jfk","1:00pm",2);
       timeTable.addDay(d1);
       String str = "19/11/3919"+"\n"+"COMP1234"+"\n"+"jfk"+"\n"+"1:00pm"+"\n"+"2"+"\n";
       assertEquals(timeTable.printDay(d),str);
       
    }
}
