

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.util.Date;
/**
 * The test class ExamDayTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ExamDayTest
{
    private ExamDay examDay;
    /**
     * Default constructor for test class ExamDayTest
     */
    public ExamDayTest()
    {
        Date d1 = new Date (2019,10,19);
        examDay = new ExamDay ("C1", d1,"1:00pm","JFK",2 );
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    @Test
    public void test_get_courseCode(){
        assertEquals("C1",examDay.get_courseCode());
    }
    
    @Test
    public void test_get_date(){
        Date d1 = new Date(2019,10,19);
        assertEquals(d1,examDay.get_date());
    }
    
    @Test
    public void test_get_time(){
        assertEquals("1:00pm",examDay.get_time());
    }
    
    @Test
    public void test_get_location(){
        assertEquals("JFK",examDay.get_location());
    }
    
    @Test
    public void test_get_difficulty(){
        assertEquals(2,examDay.get_difficulty());
    }
    
    @Test
    public void test_set_courseCode(){
        examDay.set_courseCode("COMP1");
        assertEquals("COMP1",examDay.get_courseCode());
    }
    
    @Test
    public void test_set_date(){
        Date d1 = new Date(2019,1,19);
        examDay.set_date(d1);
        assertEquals(d1,examDay.get_date());
    }
    
    @Test
    public void test_set_time(){
        examDay.set_time("9:00am");
        assertEquals("9:00am",examDay.get_time());
    }
    
    @Test
    public void test_set_location(){
        examDay.set_location("SPEC");
        assertEquals("SPEC",examDay.get_location());
    }
    
    @Test
    public void test_set_difficulty(){
        examDay.set_difficulty(3);
        assertEquals(3,examDay.get_difficulty());
    }
}
