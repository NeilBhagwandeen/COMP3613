

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.util.Date;
/**
 * The test class StudyDayTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class StudyDayTest
{
    private StudyDay studyDay;
    /**
     * Default constructor for test class StudyDayTest
     */
    public StudyDayTest()
    {
        Date d1 = new Date (2019,10,19);
        studyDay = new StudyDay("C1",d1);
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    @Test
    public void test_get_courseCode(){
        assertEquals("C1",studyDay.get_courseCode());
    }
    
    @Test
    public void test_get_date(){
        Date d1 = new Date(2019,10,19);
        assertEquals(d1,studyDay.get_date());
    }
    
    @Test
    public void test_set_courseCode(){
        studyDay.set_courseCode("COMP1");
        assertEquals("COMP1",studyDay.get_courseCode());
    }
    
    @Test
    public void test_set_date(){
        Date d1 = new Date(2019,10,19);
        studyDay.set_date(d1);
        assertEquals(d1,studyDay.get_date());
    }
}
