
/**
 * Write a description of class ExamDay here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.*;
public class ExamDay extends Day implements TestDay
{
    protected String time;
    protected String location;
    protected int difficulty;
    
    
    public ExamDay (String courseCode, Date date, String time, String location, int difficulty){
        super(courseCode, date);
        this.time = time;
        this.location = location;
        this.difficulty = difficulty;
    }
    
    
    public String get_courseCode (){
        return courseCode;
    }
    
    public Date get_date(){
        return date;
    }
    
    public String get_time (){
        return time;
    }
    
    public String get_location (){
        return location;
    }
    
    public int get_difficulty (){
        return difficulty;
    }
    
    
    public void set_courseCode(String courseCode){
        this.courseCode = courseCode;
    }
    
    public void set_date(Date date){
        this.date = date;
    }
    
    public void set_time(String time){
        this.time = time;
    }
    
    public void set_location(String location){
        this.location = location;
    }
    
    public void set_difficulty(int difficulty){
        this.difficulty = difficulty;
    }
}
