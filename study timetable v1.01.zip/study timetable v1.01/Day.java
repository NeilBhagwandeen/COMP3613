import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.*;
public abstract class Day //implements Comparable
{
    protected String courseCode;
    protected Date date;
        
    public Day (String courseCode, Date date){
        this.date = date;
        this.courseCode = courseCode;
    }
    
    //public abstract int compareTo (Day d1);    
    public abstract Date get_date();
    public abstract String get_courseCode();
    public abstract String get_time ();
    public abstract String get_location ();
    public abstract int get_difficulty ();
    public abstract void set_courseCode(String courseCode);
    public abstract void set_date(Date date);
    public abstract void set_time(String time);
    public abstract void set_location(String location);
    public abstract void set_difficulty(int difficulty);
}
