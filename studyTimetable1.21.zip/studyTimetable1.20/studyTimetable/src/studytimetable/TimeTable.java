/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studytimetable;

/**
 *
 * @author Neil Bhagwandeen
 */
import java.text.SimpleDateFormat;
import java.util.*;
public class TimeTable {
    private TreeMap <Date,Day> timeTable;
    
    public TimeTable(){
        timeTable = new TreeMap <>();
    }
    
    public boolean addStudyDay (Day d){
        Date tempd = d.get_date();
        Date trash = new Date(119,11,1);
        Date currd = new Date(trash.getYear(),trash.getMonth(),trash.getDate());
        Random randd = new Random();
	int randomInt = randd.nextInt((tempd.getDate() - currd.getDate()) + 1) + currd.getDate();
        Date randdate = new Date(tempd.getYear(),tempd.getMonth(),randomInt);
        //System.out.println(randdate.toString());
        Day tempSD = new StudyDay(d.get_courseCode(),randdate);
        boolean checker = false;
        int numtimes = 0;
        while (checker == false && numtimes <3){
            if(timeTable.get(tempSD.get_date()) == null){
                timeTable.put(tempSD.get_date(),tempSD);
                checker = true;
                numtimes++;
            }
            else{
                if(timeTable.get(tempSD.get_date()) instanceof StudyDay){
                    String str = timeTable.get(tempSD.get_date()).get_courseCode();
                    str = str + "\n"+ tempSD.get_courseCode();
                    timeTable.get(tempSD.get_date()).set_courseCode(str);
                    checker = true;
                    numtimes++;
                }
            }
            numtimes++;
        }
        return true;
    }
    
    public boolean addDay(Day d){
        timeTable.put(d.get_date(),d);
        for(int i=1;i<=d.get_difficulty();i++)
           addStudyDay(d);
        return true;
        
    }
    
    public boolean deleteDay(Date d){
        if(timeTable.isEmpty())
            return false;
        if(timeTable.get(d)==(null))
            return false;
        timeTable.remove(d);
        return true;
    }
    
    public boolean editDay(Day d){
        if(timeTable.isEmpty())
            return false;
        if (timeTable.isEmpty())
            return false;
        timeTable.get(d.get_date()).set_courseCode(d.get_courseCode());
        timeTable.get(d.get_date()).set_location(d.get_location());
        timeTable.get(d.get_date()).set_time(d.get_time());
        timeTable.get(d.get_date()).set_difficulty(d.get_difficulty());
        return true;
    }
    
    public String printDay(Date d){
        if(timeTable.isEmpty())
            return null;
        if(timeTable.get(d)==(null))
            return null;
        Day tday = timeTable.get(d);
        String str = "";
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/YYYY");
        str =  str + formatter.format(d)+ "\n";
        str = str + tday.get_courseCode() + "\n";
        if(tday instanceof TestDay){
            str = str + tday.get_time() + "\n";
            str = str + tday.get_location() + "\n";
            str = str + tday.get_difficulty() + "\n";
        }
        return str;  
    }
    
}
