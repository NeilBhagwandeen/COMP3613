/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studytimetable;

/**
 *
 * @author Neil Bhagwandeen
 */
import java.util.*;
public class StudyDay extends Day
{
    public StudyDay (String courseCode, Date date){
        super(courseCode, date);
    }
    
    
    @Override
    public String get_courseCode (){
        return courseCode;
    }
    
    @Override
    public Date get_date(){
        return date;
    }
    
    @Override
    public String get_time (){
        return null;
    }
    
    @Override
    public String get_location (){
        return null;
    }
    
    @Override
    public int get_difficulty (){
        return 0;
    }
    
    
    @Override
    public void set_courseCode(String courseCode){
        this.courseCode = courseCode;
    }
    
    @Override
    public void set_date(Date date){
        this.date = date;
    }
    
    @Override
    public void set_time(String time){
        
    }
    
    @Override
    public void set_location(String location){
        
    }
    
    @Override
    public void set_difficulty(int difficulty){
        
    }
}
